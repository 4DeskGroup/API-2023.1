import React, { Component } from "react";
import "C:/Users/stef/Documents/coding/reactJS/menu/src/components/Rodape.css";

export class Rodape extends Component {
    render() {
        return (
            <>
            <bar>
                <div className="rodape-fundo">
                    <div className="rodape-texto">
                            @ copyright - todos os direitos reservados - 2023
                    </div>
                </div>
            </bar>
            </>
        )
    }
}