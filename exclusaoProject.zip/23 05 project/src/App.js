import { Rotas } from './routes/indexRoutes';


export default  function App () {
  return (
     <>
     <Rotas />
     </>
  );
 };

