import React from 'react'
import Tabela from './tabela';

function App() {
    return (
    <div>
      <Tabela/>
    </div>
  );
}

export default App;
