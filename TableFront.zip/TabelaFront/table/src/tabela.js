import React from 'react';
import './tabela.css'




function Lista() {
  return (

    <div className='container'>

      
      
        <div className='titulo'> 
        <div className='title-container'>         
          <h1>Controle de usuários</h1>
          <hr className='title-hr'></hr>
          </div>
          <div>
           
          </div>        
                         
        </div>
        

      <div className='fundo'>
      <div className='content first-content'>

      <table className='tabela'>
        <thead> 
        <tr>
            <th>Usuario</th>
            <th>Cadastro</th>
            <th>Status</th>
            <th>Tipo</th>
        </tr>
        </thead>
        <body>
            <tr>
                <td> </td>
                <td> </td>
            </tr>
        </body>
      </table>
      </div>
      </div>
    </div>
 
    
  
  );
}



export default Lista


